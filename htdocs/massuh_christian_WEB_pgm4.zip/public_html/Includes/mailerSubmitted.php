<!--      
**************************************************
Author   : Christian Massuh
Course   : CGS4854 Online
URL      : http://ocelot.aul.fiu.edu/~cmass019
Professor: Michael Robinson
Program  : Program Number 4 - mailerSubmitted.php
Due Date : 4/8/2018

I certify that this work is my own alone.

..........{ Christian Massuh }..........
**************************************************
-->
<html>
  <head>
        <title>
            Mailer Submitted
        </title>
    </head>
              <?php include('mainMenu.php') ?>

  <body style="font-family:Palatino">
    <div align="center">
      <center>
        <table border="0" cellpadding="0" cellspacing="0" width="75%" bgcolor="#CCCCCC" height="366">
          <tr>
            <td width="75%" height="57" colspan="2" bgcolor="#ffffff" >
              <p align="center">
                
                <b>
                  <font size="6" color="black">Best Zoos in the USA - A Planning Guide</font>
                </b>
                <br><br>
                
                <font size="4">Your message has been submitted. </font>
                <br><br>
                
                <font size="6"><em>Thank you!</em></font>
                <br><br>
                
                <font size="4">One of our agents will contact you shortly.</font>
                
                <br><br>
              </p>
            </td>
          </tr>
        </table>
      </center>
    </div>
  </body>
</html>


