<!--      
**************************************************
Author   : Christian Massuh
Course   : CGS4854 Online
URL      : http://ocelot.aul.fiu.edu/~cmass019
Professor: Michael Robinson
Program  : Program Number 4 - clear.php
Due Date : 4/8/2018

I certify that this work is my own alone.

..........{ Christian Massuh }..........
**************************************************
-->

<html>
    <body>
        <?php

        $Telephone     = "";
        $LastName      = "";
        $FirstName     = "";
        $Email         = "";
        $Animals1      = "";
        $Animals2      = "";
        $Animals3      = "";
        $Animals4      = "";
        $Animals5      = "";
        $LAZoo         = "";
        $MiamiZoo      = "";
        $HoustonZoo    = "";
        $SanDiegoZoo   = "";
        $NewYorkZoo    = "";
        $Request       = "";
        $Dates         = "";

        $found         = "";                   
        ?>

    </body>
</html>
<!--end clear.php-->