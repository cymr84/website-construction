<html>
    <body>

        <!--br><h3>this is clear.php</h3><br-->                 

        <?php
        
        $Telephone     = "";
        $LastName      = "";
        $FirstName     = "";
        $Email         = "";
        $Animals1      = "";
        $Animals2      = "";
        $Animals3      = "";
        $Animals4      = "";
        $Animals5      = "";
        $LAZoo         = "";
        $MiamiZoo      = "";
        $HoustonZoo    = "";
        $SanDiegoZoo   = "";
        $NewYorkZoo    = "";
        $Request       = "";
        $Dates         = "";

        $found         = "";                   
        
        ?>

    </body>
</html>

<!--end clear.php-->