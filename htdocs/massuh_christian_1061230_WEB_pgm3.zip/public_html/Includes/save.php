<html>
   <body>

      <!--br><h3>this is save.phd</h3><br-->

      <?php
        
//       echo $Telephone."<br>"; 
//       echo $LastName."<br>";  
//       echo $FirstName."<br>";  
//       echo $Email."<br>";  
//       echo $Animals1."<br>";  
//       echo $Animals2."<br>";  
//       echo $Animals3."<br>"; 
//       echo $Animals4."<br>";
//       echo $Animals5."<br>";
//       echo $LaZoo."<br>";  
//       echo $MiamiZoo."<br>";  
//       echo $HoustonZoo."<br>";  
//       echo $SanDiegoZoo."<br>";  
//       echo $NewYorkZoo."<br>";  
//       echo $Request."<br>";  
//       echo $Dates."<br>";  
     
       echo "inserting record into table ".$tableName."<br>";
          

      $Telephone=trim($Telephone);
      if(strlen($Telephone)>0)           
      {   
         $sql="INSERT INTO zootrip (
                  Telephone,
                  LastName,
                  FirstName,
                  Email,
                  Animals1,
                  Animals2,
                  Animals3,
                  Animals4,
                  Animals5,
                  LAZoo,
                  MiamiZoo,
                  HoustonZoo,
                  NewYorkZoo,
                  Request,
                  Dates
               )
               VALUES
               (            
                  '$Telephone',
                  '$LastName',
                  '$FirstName',
                  '$Email',
                  '$Animals1',
                  '$Animals2',
                  '$Animals3',
                  '$Animals4',
                  '$Animals5',
                  '$LaZoo',
                  '$MiamiZoo',
                  '$HoustonZoo',
                  '$NewYorkZoo',
                  '$Request',
                  '$Dates'
               )";

//         only one primary key at a time
         
         if (mysqli_query($connection, $sql))   
         {
            //echo "<br>New record created successfully";
            $message ="<span style=\"color: red;\">RECORD $found ADDED</span><br\>";
         } 

         else
         {
            echo "<br>Error: " . $sql . "<br>" . mysqli_error($connection);
            $message ="<span style=\"color: red;\">RECORD $found EXISTS NOT ADDED</span><br\>";
         }
      }//end if(strlen($Telephone)>0)

      else
      {
         $message ="<span style=\"color: red;\">RECORD NOT ADDED<BR>Telephone CAN NOT BE EMPTY</span><br\>";
      } 
      
      ?>


   </body>
</html>
