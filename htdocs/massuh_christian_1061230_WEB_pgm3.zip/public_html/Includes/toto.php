<html>
                     
  <body>
      
      <?php
    
      $sql="SELECT * FROM zootrip where Telephone = '$Telephone'";

      if ($result=mysqli_query($connection,$sql))
      {

         $rowcount=mysqli_num_rows($result);


         while( $row = mysqli_fetch_array( $result ) )
         {
            $Telephone    = $row['Telephone'];     //primary key
            $LastName     = $row['LastName'];      //type="text"
            $FirstName    = $row['FirstName'];     //type="text"
            $Email        = $row['Email'];         //type="text"
            $Animals1     = $row['Animals1'];      //type="radio"
            $Animals2     = $row['Animals2'];      //type="radio"
            $Animals3     = $row['Animals3'];      //type="radio"
            $Animals4     = $row['Animals4'];      //type="radio"
            $Animals5     = $row['Animals5'];      //type="radio"
            $LAZoo        = $row['LAZoo'];         //type="checkbox"
            $MiamiZoo     = $row['MiamiZoo']       //type="checkbox" 
            $HoustonZoo   = $row['HoustonZoo'];    //type="checkbox"
            $NewYorkZoo   = $row['NewYorkZoo'];    //type="text"
            $Request      = $row['Request'];  //type="textarea"
            $Dates        = $row['Dates'];         //type="dropdown" 
         }

       

         $Telephone=trim($Telephone); 
         if ( $rowcount )
         {
            $found = $Telephone;
            $message ="<span style=\"color: red;\">RECORD $found FOUND</span><br\>";
         } 
         
         else if( strlen($Telephone) ==0 )           
         {
            $message ="<span style=\"color: red;\">Telephone CAN NOT BE EMPTY</span><br>";

            $LastName      = "";
            $FirstName     = "";
            $Email         = "";
            $Animals1      = "";
            $Animals2      = "";
            $Animals3      = "";
            $Animals4      = "";
            $Animals5      = "";
            $LAZoo         = "";
            $MiamiZoo      = "";
            $HoustonZoo    = "";
            $NewYorkZoo    = "";
            $Request       = "";
            $Dates         = "";             

            $found         = "";  
         }
         
         else 
         {
            $message ="<span style=\"color: red;\">RECORD $Telephone NOT FOUND</span><br>";

            $LastName      = "";
            $FirstName     = "";
            $Email         = "";
            $Animals1      = "";
            $Animals2      = "";
            $Animals3      = "";
            $Animals4      = "";
            $Animals5      = "";
            $LAZoo         = "";
            $MiamiZoo      = "";
            $HoustonZoo    = "";
            $NewYorkZoo    = "";
            $Request       = "";
            $Dates         = "";

            $found         = "";  
         }
      }
      
      ?>
 </body>

</html>//end find

